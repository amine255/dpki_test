# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

from scrapy.item import Item, Field

class InterieurItem(Item):
    Site = Field()
    Ville = Field()
    Statut = Field()
    Surface_GLA = Field()
    Nb_boutiques = Field()
    Surface_hyper = Field()
    Contact = Field()
    Fonction = Field()
    Mail = Field()
    Telephone = Field()
    Mobile = Field()

